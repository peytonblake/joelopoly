Joelopoly, yo
It's a board game don't you know
To play you role the dice
Buy property if it's nice
Run out of money and you'll fail
We'll put you straight in jail
