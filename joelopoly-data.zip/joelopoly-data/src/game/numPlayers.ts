class NumPlayers {
    numHumanPlayers: number = 2;
    numAIPlayers: number = 0;
}

const numPlayers = new NumPlayers();
export default numPlayers;
