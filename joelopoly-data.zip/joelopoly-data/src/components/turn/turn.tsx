const todo = "todo";
export default todo;