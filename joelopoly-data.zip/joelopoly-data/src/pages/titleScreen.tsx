import React from 'react';
import Title from '../components/title';

const TitleScreen = () => {
  return (
    <>
      <Title />
    </>
  );
};

export default TitleScreen;
