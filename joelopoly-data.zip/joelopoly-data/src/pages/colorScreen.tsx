import React from 'react';
import Color from '../components/color';


const ColorScreen = () => {
  return (
    <>
      <Color />
    </>
  );
};

export default ColorScreen;