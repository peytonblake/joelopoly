import React from 'react';
import Game from '../components/game';

const GameScreen = () => {
  return (
    <>
      <Game />
    </>
  );
};

export default GameScreen;