import React from 'react';
import Turn from '../components/turn';

const TurnScreen = () => {
  return (
    <>
      <Turn />
    </>
  );
};

export default TurnScreen;